class Cube {

   constructor(randomPos) {
    this.node = document.createElement("div");

    gameBoxNode.append(this.node)
    this.x = gameBoxNode.offsetWidth;
    this.y = randomPos;

    this.height = 60;
    this.width = 50;
    

    this.node.style.position = "absolute";
    this.node.style.left = `${this.x}px`;
    this.node.style.top = `${this.y}px`;
    this.node.style.height = `${this.height}px`;
    this.node.style.width = `${this.width}px`;

    this.node.style.backgroundColor = "#B22222";
  
  //enemy methods
 
}
 automaticMovementLeft(){

    this.x -= 2
    this.node.style.left = `${this.x}px`
  }
}

 

