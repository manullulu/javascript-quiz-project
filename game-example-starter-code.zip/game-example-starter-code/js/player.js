class Player {

  constructor() {
    this.node = document.createElement("div");

    gameBoxNode.append(this.node)
    this.x = 40;
    this.y = 170;

    this.height = 60;
    this.width = 60;
    this.node.style.borderRadius = "30px" 

    this.node.style.position = "absolute";
    this.node.style.left = `${this.x}px`;
    this.node.style.top = `${this.y}px`;
    this.node.style.height = `${this.height}px`;
    this.node.style.width = `${this.width}px`;

    this.node.style.backgroundColor = "#B1F4E7 ";
  }

  //* all player methods will go here
  moveUp() {
    if(this.y <= 0){return}
    this.y -= 20;
    this.node.style.top = `${this.y}px`;
}

  moveDown() {
    if((this.y + this.height) >= gameBoxNode.offsetHeight){return}
    this.y += 20;
    this.node.style.top = `${this.y}px`;
}
}