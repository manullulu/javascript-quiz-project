//* GLOBAL DOM ELEMENTS
const startScreenNode = document.querySelector("#start-screen");
const gameScreenNode = document.querySelector("#game-screen");
const gameOverScreenNode = document.querySelector("#game-over-screen");
const startBtnNode = document.querySelector("#start-btn");
const gameBoxNode = document.querySelector("#game-box");

//* GLOBAL GAME VARIABLES
let playerObj = null;
//let enemyObj = null;
let enemiesArr = [];
let gameIntervalId = null;
let enemySpawnintervalId = null;
//* GLOBAL GAME FUNCTIONS
function startGame() {
  startScreenNode.style.display = "none";
  gameScreenNode.style.display = "flex";

playerObj = new Player()

gameIntervalId = setInterval(gameLoop, Math.floor(1000/60))
enemySpawnintervalId = setInterval( addNewenemy, Math.floor(Math.random()* (2000 - 500) + 500))
}


function gameLoop(){
    enemiesArr.forEach((enemyObj) => {
        enemyObj.automaticMovementLeft()
        
    })
    checkEnemyDespawn();
    checkCollisionPvE();
}
function addNewenemy() {
    let randomPos = Math.random() * 400;
    let enemyObj = new Cube(randomPos) 
        enemiesArr.push(enemyObj);
}
//! to remove an element, we need to remove from both enviornments, Remove from DOM and remove form any JS checking it.
function checkEnemyDespawn () { 
    if(enemiesArr.length === 0){return}
    if(enemiesArr[0].x <= (0 -enemiesArr[0].width)) {
        enemiesArr[0].node.remove()
        enemiesArr.splice(0, 1);
    }
}
function checkCollisionPvE(){
    enemiesArr.forEach((enemyObj)=> {
        if(checkCollision (playerObj, enemyObj)){
            gameOver();
        }
    })
}
function gameOver(){
    gameScreenNode.style.display = "none"
    gameOverScreenNode.stye.display = "flex"
    clearInterval(gameIntervalId)
    clearInterval(enemySpawnintervalId)


}
function checkCollision(element1, element2) {
  return (
    element1.x < element2.x + element2.width &&
    element1.x + element1.width > element2.x &&
    element1.y < element2.y + element2.height &&
    element1.y + element1.height > element2.y
  ); // true if colliding, false if not colliding
}




//* EVENT LISTENERS
startBtnNode.addEventListener("click", startGame)
window.addEventListener("keydown", (event) => {
      if (event.key === "ArrowUp") {
        playerObj.moveUp();
      } else if (event.key === "ArrowDown") {
        playerObj.moveDown();
      }
}
)
